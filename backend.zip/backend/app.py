from flask import Flask, request, jsonify
from flask_cors import CORS
import pandas as pd
from langchain.chains import create_retrieval_chain
from langchain.prompts import PromptTemplate
from transformers import AutoTokenizer, AutoModelForCausalLM, pipeline
from langchain_community.vectorstores import Chroma  # Updated import
from langchain_community.embeddings import HuggingFaceEmbeddings  # Updated import
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.schema import Document  # Use Document objects

app = Flask(__name__)
CORS(app)

# Load sales data
data = pd.read_csv('E:/forecasting_with_llm1/data/extended_car_accessory_sales.csv')

# Convert rows to Document objects for retrieval
docs = [Document(page_content=str(row), metadata={'index': i}) for i, row in data.iterrows()]
text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
splits = text_splitter.split_documents(docs)

# Setup the embedding model and Chroma vector store
embedding = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
vectorstore = Chroma.from_documents(documents=splits, embedding=embedding)
retriever = vectorstore.as_retriever()

# Load the model and tokenizer locally
tokenizer = AutoTokenizer.from_pretrained("HuggingFaceH4/zephyr-7b-beta")  # or another model of choice
model = AutoModelForCausalLM.from_pretrained("HuggingFaceH4/zephyr-7b-beta")

# Initialize the pipeline for local inference
llm_pipeline = pipeline("text-generation", model=model, tokenizer=tokenizer)

# Define the RAG chain
system_prompt = """
You are tasked with answering the following question using the given context. Use the retrieved context to improve the answer.\n{context}
"""
prompt = PromptTemplate(template=system_prompt, input_variables=["context", "input"])

@app.route('/api/forecast', methods=['POST'])
def forecast():
    user_input = request.json.get('input')
    context = retriever.retrieve(user_input)
    
    # Use the pipeline for text generation
    generated_response = llm_pipeline(user_input, max_length=150, do_sample=True, temperature=0.7)
    
    return jsonify({"answer": generated_response[0]["generated_text"]})

if __name__ == '__main__':
    app.run(debug=True)
