import streamlit as st
import requests

# Title of the app
st.title("B2B Automobile Accessories Forecasting with LLM")

# Input fields for user queries
user_input = st.text_input("Enter your question about the sales forecast:")

# Button to submit the query
if st.button("Get Forecast"):
    # API request to the backend
    response = requests.post("http://localhost:5000/api/forecast", json={"input": user_input})
    
    # Display the answer from the RAG model
    if response.status_code == 200:
        st.write("Forecast Answer:")
        st.write(response.json()["answer"])
    else:
        st.write("Error:", response.status_code)
